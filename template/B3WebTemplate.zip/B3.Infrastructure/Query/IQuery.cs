﻿namespace $safeprojectname$.Query
{
    public interface IQuery<TResult>
    {
         
    }
}