﻿using System.Collections.Generic;

namespace $safeprojectname$.Pagination
{
    public class PagedResult<T> : IPagedResult<T> where T : class
    {
        public PageInfo PageInfo { get; }

        public IList<T> Data { get; }

        public PagedResult(IList<T> items, PageInfo pageInfo)
        {
            PageInfo = pageInfo;
            Data = items;
        }
    }
}