﻿namespace $safeprojectname$.Command
{
    public interface ICommand
    {
         
    }
}