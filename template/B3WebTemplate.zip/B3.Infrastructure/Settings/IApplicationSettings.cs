﻿namespace $safeprojectname$.Settings
{
    public interface IApplicationSettings
    {
        string ConnectionSettings { get; }
        string DatabaseType { get; }
        int DefaultPageSize { get; }
    }
}