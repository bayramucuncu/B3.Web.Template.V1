﻿namespace $safeprojectname$.Entity
{
    public interface IValueObject
    {

    }
}