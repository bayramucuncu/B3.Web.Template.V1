﻿namespace $safeprojectname$.Entity
{
    public interface IAggregateRoot
    {
        
    }
}