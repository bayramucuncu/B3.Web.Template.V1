﻿namespace $safeprojectname$.DependencyInjection
{
    public interface IDependencyModule
    {
        void LoadDependencies();
    }
}