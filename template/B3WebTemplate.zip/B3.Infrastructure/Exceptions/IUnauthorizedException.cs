﻿namespace $safeprojectname$.Exceptions
{
    public interface IUnauthorizedException
    {
        
    }
}