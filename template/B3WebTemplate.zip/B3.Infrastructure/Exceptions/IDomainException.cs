﻿namespace $safeprojectname$.Exceptions
{
    public interface IDomainException
    {
        
    }
}