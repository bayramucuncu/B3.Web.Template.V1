﻿namespace $safeprojectname$.Exceptions
{
    public interface IApplicationServiceException
    {
        
    }
}