﻿namespace $safeprojectname$.Exceptions
{
    public interface INotFountException
    {
        
    }
}