﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class InvalidPropertyFormatException : Exception, IDomainException
    {
        public InvalidPropertyFormatException(string name)
            : base($"{name} property has invalid format!")
        {
        }
    }
}