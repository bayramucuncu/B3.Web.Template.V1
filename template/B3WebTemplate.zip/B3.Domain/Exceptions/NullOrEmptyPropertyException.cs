﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class NullOrEmptyPropertyException : Exception, IDomainException
    {
        public NullOrEmptyPropertyException(string name)
            : base($"{name} property has null value!")
        {
        }
    }
}