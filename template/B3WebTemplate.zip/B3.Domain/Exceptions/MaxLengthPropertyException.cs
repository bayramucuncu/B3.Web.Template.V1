﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class MaxLengthPropertyException : Exception, IDomainException
    {
        public MaxLengthPropertyException(string name, int length)
            : base($"{name} property length must be {length} character long or less!")
        {
        }
    }
}