﻿using System.Threading.Tasks;

namespace $safeprojectname$.Event
{
    public interface IEventDispatcher
    {
        Task DispatchAsync<TEvent>(params TEvent[] events) where TEvent : IEvent;
    }
}