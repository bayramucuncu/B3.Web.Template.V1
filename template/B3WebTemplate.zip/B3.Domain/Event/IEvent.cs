﻿namespace $safeprojectname$.Event
{
    public interface IEvent
    {
        
    }
}