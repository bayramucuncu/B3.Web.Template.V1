﻿using System.Threading.Tasks;

namespace $safeprojectname$.Event
{
    public interface IEventHandler<in TEvent> where TEvent : IEvent
    {
        Task HandleAsync(TEvent domainEvent);
    }
}