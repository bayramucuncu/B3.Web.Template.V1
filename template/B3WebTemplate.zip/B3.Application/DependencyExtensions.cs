﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
    public static class DependencyExtensions
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            // ToDo: add service dependencies.

            return services;
        }
    }
}