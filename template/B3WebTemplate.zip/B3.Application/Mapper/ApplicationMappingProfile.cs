﻿using AutoMapper;

namespace $safeprojectname$.Mapper
{
    public class ApplicationMappingProfile : Profile
    {
        public ApplicationMappingProfile()
        {
            // ToDo: CreateMap<TSource, TDestination>();
        }
    }
}
