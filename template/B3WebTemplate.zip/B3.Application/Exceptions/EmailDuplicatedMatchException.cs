﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class EmailDuplicatedMatchException : Exception, IApplicationServiceException
    {
        public EmailDuplicatedMatchException()
            : base("This email is used before by another user!")
        {
        }
    }
}