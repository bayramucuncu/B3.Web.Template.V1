﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class EntityNotFoundException : Exception, INotFountException
    {
        public EntityNotFoundException(string name)
            : base($"{name} could not found!")
        {
        }
    }
}