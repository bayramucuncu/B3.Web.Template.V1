﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class UsernameDuplicatedMatchException : Exception, IApplicationServiceException
    {
        public UsernameDuplicatedMatchException()
            : base("This username is used before by another user!")
        {
        }
    }
}