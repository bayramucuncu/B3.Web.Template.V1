﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class StaticEntityDeletePermissionException : Exception, IApplicationServiceException
    {
        public StaticEntityDeletePermissionException(string name)
            : base($"Static {name} cannot be deleted!")
        {
        }
    }
}