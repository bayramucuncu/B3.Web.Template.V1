﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class UserPasswordsDoesNotMatchException : Exception, IApplicationServiceException
    {
        public UserPasswordsDoesNotMatchException()
            : base("New Passwords does not match!")
        {
        }
    }
}