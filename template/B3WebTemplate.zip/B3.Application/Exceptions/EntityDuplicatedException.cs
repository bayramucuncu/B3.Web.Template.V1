﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class EntityDuplicatedException : Exception, IApplicationServiceException
    {
        public EntityDuplicatedException()
            : base($"This record is already exist!")
        {
        }
    }
}