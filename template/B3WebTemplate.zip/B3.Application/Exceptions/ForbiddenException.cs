﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class ForbiddenException : Exception, IUnauthorizedException
    {
        public ForbiddenException()
            : base("You do not have permissions for this operation!")
        {
        }
    }
}