﻿using System;
using $ext_safeprojectname$.Infrastructure.Exceptions;

namespace $safeprojectname$.Exceptions
{
    public class StaticEntityUpdatePermissionException : Exception, IApplicationServiceException
    {
        public StaticEntityUpdatePermissionException(string name)
            : base($"Static {name} cannot be updated!")
        {
        }
    }
}