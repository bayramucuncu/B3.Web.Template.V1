﻿using $safeprojectname$.Mapper;
using $ext_safeprojectname$.Infrastructure.AutoMapper;
using $ext_safeprojectname$.Infrastructure.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
    public class DependencyModule: IDependencyModule
    {
        private readonly IServiceCollection _serviceCollection;

        public DependencyModule(IServiceCollection serviceCollection)
        {
            _serviceCollection = serviceCollection;
        }

        public void LoadDependencies()
        {
            _serviceCollection.AddTransient<IObjectMapper, AutoMapperObjectMapper>();
            _serviceCollection.AddSingleton(AutoMapperBootstrap.GetConfiguration());
        }
    }
}